import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import '../../config/api_config.dart';
import '../../providers/app_provider.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {

  bool loading = true;

  List users = [];

  @override
  void initState() {
    super.initState();
    loadUsers();
  }

  Future<void> loadUsers() async {

    final provider =
        Provider.of<AppProvider>(context, listen: false);

    final response = await http.get(
      Uri.parse(ApiConfig.endpoint('/admin/users')),
      headers: {
        "Authorization":
            "Bearer ${provider.authToken}",
      },
    );

    if (response.statusCode == 200) {

      setState(() {

        users = jsonDecode(response.body);

        loading = false;

      });

    } else {

      setState(() {

        loading = false;

      });

    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text("Users"),
      ),

      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView.builder(

              itemCount: users.length,

              itemBuilder: (context, index) {

                final user = users[index];

                return Card(

                  margin: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),

                  child: ListTile(

                    leading: CircleAvatar(
                      child: Text(
                        user["name"][0].toUpperCase(),
                      ),
                    ),

                    title: Text(user["name"]),

                    subtitle: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [

                        Text(user["email"]),

                        Text(
                          "Role : ${user["role"]}",
                        ),

                        Text(
                          "Goal : ${user["daily_goal"]}",
                        ),

                      ],
                    ),

                  ),

                );
              },
            ),
    );
  }
}