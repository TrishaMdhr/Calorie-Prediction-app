import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import '../../config/api_config.dart';
import '../../providers/app_provider.dart';

class FoodsScreen extends StatefulWidget {
  const FoodsScreen({super.key});

  @override
  State<FoodsScreen> createState() => _FoodsScreenState();
}

class _FoodsScreenState extends State<FoodsScreen> {
  List foods = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadFoods();
  }

  Future<void> loadFoods() async {
    try {
      final provider =
          Provider.of<AppProvider>(context, listen: false);

      final response = await http.get(
        Uri.parse(ApiConfig.endpoint('/admin/foods')),
        headers: {
          "Authorization": "Bearer ${provider.authToken}",
        },
      );

      if (response.statusCode == 200) {
        setState(() {
          foods = jsonDecode(response.body);
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      debugPrint("Foods Error: $e");

      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Foods"),
      ),
      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView.builder(
              itemCount: foods.length,
              itemBuilder: (context, index) {
                final food = foods[index];

                return Card(
                  margin: const EdgeInsets.all(10),
                  child: ListTile(
                    title: Text(food["food_name"].toString()),
                    subtitle: Text(
                      "Calories: ${food["calories"]}\n"
                      "Protein: ${food["protein"]} g\n"
                      "Carbs: ${food["carbs"]} g\n"
                      "Fat: ${food["fat"]} g",
                    ),
                  ),
                );
              },
            ),
    );
  }
}